# Kubernetes Cluster
master: 10.62.100.73
minion1: 10.62.100.73
minion2: 10.62.100.74
minion3: 10.62.100.75

# Run Cluster Step
step1: put application in /usr/local/bin
      master: etcd/kube-apiserver/kube-controller-manager/kube-scheduler
      minion: kubelet/kube-proxy

step2: execute script
       master: env.sh--->
               kube-etcd.sh--->
               kube-apiserver.sh--->
               kube-controller-manager.sh--->
               kube-scheduler.sh
        minion: env.sh--->
                kubelet.sh--->
                kube-proxy.sh

# Reference
http://www.cnblogs.com/lyzw/p/6016789.html