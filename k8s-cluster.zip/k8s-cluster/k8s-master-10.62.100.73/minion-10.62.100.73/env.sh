#!/bin/sh

export MASTER_IP='10.62.100.73'