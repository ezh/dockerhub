#!/bin/bash
export http_proxy=
export https_proxy=
proxy=/opt/kubernetes/bin/kube-proxy

$proxy \
  --master=10.62.100.73:8080 &
