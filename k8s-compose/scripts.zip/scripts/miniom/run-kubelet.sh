#!/bin/bash
export http_proxy=
export https_proxy=
kubelet=/opt/kubernetes/bin/kubelet
$kubelet  \
  --api-servers=10.62.100.73:8080 \
  --pod-infra-container-image=10.62.100.97:5000/kubernetes/pause \
  --hostname-override="10.62.100.74" &
