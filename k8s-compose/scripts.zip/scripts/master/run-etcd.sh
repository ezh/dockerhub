#!/bin/bash
etcd=/opt/kubernetes/bin/etcd
$etcd \
  --initial-advertise-peer-urls http://10.62.100.73:7001 \
  --advertise-client-urls http://10.62.100.73:4001 \
  --listen-peer-urls http://0.0.0.0:7001 \
  --listen-client-urls http://0.0.0.0:4001 \
  --initial-cluster default=http://10.62.100.73:7001 &
