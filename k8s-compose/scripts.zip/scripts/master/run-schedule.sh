#!/bin/bash
scheduler=/opt/kubernetes/bin/kube-scheduler
$scheduler --master=10.62.100.73:8080 &
