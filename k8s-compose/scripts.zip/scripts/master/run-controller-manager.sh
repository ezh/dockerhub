#/bin/bash

manager=/opt/kubernetes/bin/kube-controller-manager
$manager --master=10.62.100.73:8080 &
