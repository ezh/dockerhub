#!/bin/sh

export MASTER_IP='10.62.100.73'
export CLUSTER_IP_RANGE='172.17.0.0/24'
