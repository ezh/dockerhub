#!/bin/sh


/usr/local/bin/kube-scheduler --master=10.62.100.73:8080
